tempOfCelsium = int(input("Введите температуру в градусах Цельсия: "))

tempOfFarenheit = tempOfCelsium * 9 / 5 + 32

print("Температура в Фаренгейтах: ", tempOfFarenheit)
