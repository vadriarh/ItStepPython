name = input("Введите свое имя: ")
print("Привет, ", name + ".")
