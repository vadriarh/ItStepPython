numberOne = int(input("Введите первое число: "))
numberTwo = int(input("Введите второк число: "))

summa = numberOne + numberTwo

print("Сумма: ", summa)