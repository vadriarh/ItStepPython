people = {
    "Вася": 25,
    "Аня": 30,
    "Петя": 20
}
age = people["Аня"]
print(age)
