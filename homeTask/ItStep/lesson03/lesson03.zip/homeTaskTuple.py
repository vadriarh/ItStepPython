my_tuple = (10, 20, 30, 40)
elementOfTuple = my_tuple[1]
print(elementOfTuple)
