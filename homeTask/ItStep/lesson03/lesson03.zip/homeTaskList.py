numbers = [3, 8, 1, 6, 10, 2]
numberMax = max(numbers)
print(numberMax)
